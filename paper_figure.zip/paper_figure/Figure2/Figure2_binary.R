### Figure 2. binary response. error vs sample size; fixed matrix dimension; 
source("NonMar.R")
set.seed(1)
truer = 2; support = 2;
truer = 2; support = 3;
truer = 5; support = 5;
hyper_list=rbind(c(2,2),c(2,3),c(5,5))


signal=1;
nsim=30; #hyper=1;
n_list=c(150,200,250,300,350)
#error=error_set=array(0,dim=c(3,length(n_list),nsim))
error=rep(0,nsim)

args <- (commandArgs(trailingOnly=TRUE))
cat(args[1])
if(length(args) == 1){
    BATCH <- as.numeric(args[1])
} else {
    stop()
}
indset = matrix(0,nrow = 15,ncol = 2)
s = 0
for(i in 1:3){
    for(j in 1:5){
    s = s+1
    indset[s,]= c(i,j)
}
}
hyper = indset[BATCH,][1]
config = indset[BATCH,][2]

#for(hyper in 1:3){
    truer=hyper_list[hyper,1];support=hyper_list[hyper,2]
# for(config in 1:length(n_list)){
        n = n_list[config]; d=20;
        sparse = d - support;
        ## simulate B
        rU = randortho(d)[,1:truer]
        rV= randortho(d)[,1:truer]
        B = rU%*%t(rV)
        B[1:sparse,]=0
        B[,1:sparse]=0

        for(sim in 1:nsim){
            X = list();
            for(i in 1:n){
                X[[i]] = matrix(runif(d^2,-1,1),nrow =d,ncol = d)
            }
            ystar= unlist(lapply(X,function(x) sum(B*x)))
            ## logistic model
            #ystar=2*(ystar-min(ystar))/(max(ystar)-min(ystar))-1
            
            
            #ystar1=2*(1/n*(1:n)[rank(ystar)]-0.5)
            ystar1=qnorm(1/(n+1)*(1:n))[rank(ystar)]
            ## seperable model
            pb= link(type="logistic")(ystar1*signal)
     
     #y = rnorm(n,pb,0.1)
      y = ifelse(sapply(pb,function(x) rbinom(1,1,(x+1)/2))==1,1,-1)

            
            ########### prob
            res=NonparaMatrix(X,y,r=truer,sparse_r=sparse,sparse_c= sparse,H=sqrt(n)-8,lambda=0,rho.ini=1,min=max(-1,min(y)),max=min(1,max(y)))
        
        error[sim]=mean(abs(res$prob-pb))
        #error[hyper,config,sim]=mean(abs(res$prob-pb))
            print(paste("hyper",hyper,"-config",config,"-simulation",sim," is done",sep = ""))
        }
        #}
        #}

#save(final,file=paste("cv",r,"-",cost,"-",k,".RData",sep=""))


save(error,file=paste("Figure2-binary-hyper",hyper,"-config",config,".RData",sep=""))
#data=cbind(c(t(error)),rep(1:5,rep(5,5)))
#data=data.frame(est=data[,1],d=as.factor(data[,2]))
#p=ggplot(data,aes(x=d,y=est))+geom_violin()

####################
### fixed n, increase d

###################




library(ggplot2)

Terror=array(0,dim=c(3,length(n_list),nsim))

for(hyper in 1:3){
    for(config in 1:5){
        load(file=paste("Figure2-binary-hyper",hyper,"-config",config,".RData",sep=""))
        Terror[hyper,config,]=error
    }
}
error=Terror


plotdata =data.frame(error=c(t(apply(error,1:2,mean))),sd=c(t(apply(error,1:2,sd))),n=rep(n_list,3),setting=rep(c("r=2,s=2","r=2,s=3","r=5,s=5"),rep(5,3)))

plotdata[,2]=plotdata[,2]/sqrt(30)

#fun.1 <- function(x) 0.2/x^(1/3)
fun.1 <- function(x) 2.9/x^(1/3)



pdf("Figure2_binary.pdf",width=6,height=5)
figure = ggplot(data = plotdata, aes(x = n,y = error),shape=1,color=1)+theme(axis.text.y = element_text(size = 16),axis.text.x = element_text(size = 16),axis.title.x = element_text(size = 16),axis.title.y = element_text(size = 16),)+geom_line(aes(color=setting),size=1.5)+labs(y = "regression error",x = "sample size")+geom_point(aes(shape=setting),size = 2)+scale_color_manual(values=c("#C4961A", "#4E84C4", "#52854C"))

figure=figure+ geom_errorbar(aes(ymin=error-sd,ymax=error+sd),width=0.001,position=position_dodge(0.01))+coord_cartesian(ylim = c(0.1,0.55))+stat_function(fun = fun.1,linetype = 2)+scale_shape_manual(values = c(1,4,2))
