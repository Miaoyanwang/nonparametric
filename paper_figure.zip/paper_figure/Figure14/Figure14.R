### Figure 14. error vs sample size; fixed matrix dimension; beta=0
source("../../SMMKfunctions_con.R")
set.seed(1)
library(glmnet)
library(graphclass)
library(pROC)
library(keras)


####################  setting  ####################
n=240; d=68; noise=0.01; nsim=30
#################### active edges ####################
nblock=4;
load("circle.RData")
support=33;truer=20; ## upper limit
#################### simulate X  ####################
prediction_ours=prediction_logistic=prediction_lasso=prediction_CNN=selection_ours=selection_lasso=selection_logistic=classification_logistic=classification_lasso=classification_ours=classification_CNN=rep(0,nsim)

sample=c(1,2,5,7)
sign=c(-1,-1,1,-1)
rev=c(1,0,0,0)

#################### run replicates ####################
for(sim in 1:nsim){
    pb= (1:n)/(n+1) ## y distribution
    y = ifelse(sapply(pb,function(x) rbinom(1,1,x))==1,1,-1) ## response
    X = list()
    for(i in 1:n){
        X[[i]]=matrix(0,nrow=d,ncol=d)
        for(index in 1:nblock){
            X[[i]][which(B[,,index]!=0,arr.ind=T)]=f(pb[i],sample[index],sign[index],rev[index]) ## asymetric
        }
        noise_matrix=matrix(rnorm(d^2,0,noise),nrow=d,ncol=d)
        X[[i]]=X[[i]]+noise_matrix
    }
    xvec=xvec_sym=NULL
    for(i in 1:n){
        xvec=rbind(xvec,c(X[[i]]))
        xvec_sym=rbind(xvec_sym,matrix_to_vec(X[[i]]))
    }

hold=sample(1:n,round(n/3),replace=F)
y_test=y[hold];X_test=X[hold];xvec_test=xvec[hold,];pb_test=pb[hold];
y_train=y[-hold];X_train=X[-hold];xvec_train=xvec[-hold,];pb_train=pb[-hold];
xvecsym_test=xvec_sym[hold,];xvecsym_train=xvec_sym[-hold,];

### method 1 regular lasso
res1=Lasso(xvec_train,y_train,xvec_test,lambda=0.047)
### method 2. logistic with group lasso
res2=graphclass(xvecsym_train,y_train,xvecsym_test,lambda = 1e-3, rho = 1,type = "intersection")
### method 3. our method
res3=NonparaMatrix(X_train,y_train,X_test,truer=truer,support=support)
### method 4. CNN
res4=CNN(X_train,y_train,X_test)

prediction_lasso[sim]=mean(abs(res1$prob-pb_test))/mean(pb_test)
classification_lasso[sim]=mean(abs((res1$prob>0.5)-(pb_test>0.5)))/2
prediction_logistic[sim]=mean(abs(res2$Yfit_test-pb_test))/mean(pb_test)
classification_logistic[sim]=mean(abs((res2$Yfit_test>0.5)-(pb_test>0.5)))/2
prediction_ours[sim]=mean(abs(res3$prob-pb_test))/mean(pb_test)
classification_ours[sim]=mean(abs((res3$prob>0.5)-(pb_test>0.5)))/2
prediction_CNN[sim]=mean(abs(res4$prob-pb_test))/mean(pb_test)
classification_CNN[sim]=mean(abs((res4$prob>0.5)-(pb_test>0.5)))/2

########## selection accracy
true=apply(B,1:2,sum)
v0=v1=v2=v3=rep(0,length(true))
v0[true!=0]=1
v1[matrix(res1$B_est,nrow=d,ncol=d)!=0]=1
v2[get_matrix(res2$beta)!=0]=1
v3[visualization(res3$B_est,percent=1-mean(v0),window=0.2)!=0]=1
selection_lasso[sim]=mean(v1[v0==1])
selection_logistic[sim]=mean(v2[v0==1])
selection_ours[sim]=mean(v3[v0==1])
}


res=NonparaMatrix(X,y,X,truer=truer,support=support,cost=20,H=20)
save(res,X,y,file="selection.RData")

load("selection.RData")
library(ggplot2)
source("../../../rcodes/SMMKfunctions_con.R")
FMD1=function_matrix_denoise(res,X,which(B[,,1]!=0,arr.ind=T)[,1],which(B[,,1]!=0,arr.ind=T)[,2],group="g1")
FMD2=function_matrix_denoise(res,X,which(B[,,2]!=0,arr.ind=T)[,1],which(B[,,2]!=0,arr.ind=T)[,2],group="g2")
FMD3=function_matrix_denoise(res,X,which(B[,,3]!=0,arr.ind=T)[,1],which(B[,,3]!=0,arr.ind=T)[,2],group="g3")
FMD4=function_matrix_denoise(res,X,which(B[,,4]!=0,arr.ind=T)[,1],which(B[,,4]!=0,arr.ind=T)[,2],group="g4")

pdf("FMD.pdf",width=5,height=4)
data=rbind(FMD1,FMD2,FMD3,FMD4)
library(ggplot2)
data=rbind(FMD1$data,FMD2$data,FMD3$data,FMD4$data)
p=ggplot(data, aes(x=prob, y=effect))+geom_jitter(aes(x=prob, y=effect, color=group),width = 0.01,height =0,size=0.2)+labs(x = "Estimated response probability")+labs(y="Edge connectivity")+stat_smooth(aes(x=prob, y=effect, color=group),level=0.68,fill = "gray80",size=0.5)+labs(x = "Estimated response probability")+labs(y="Edge connectivity")
p=p+stat_function(fun = function(x) f(x,1,sign[1],rev[1]),linetype = 2,color="gray50")+stat_function(fun = function(x) f(x,3,sign[2],rev[2]),linetype = 2,color="gray50")+stat_function(fun = function(x) f(x,5,sign[3],rev[3]),linetype = 2,color="gray50")+stat_function(fun = function(x) f(x,7,sign[4],rev[4]),linetype = 2,color="gray50")
p
dev.off()

pdf("est_circle.pdf",width=4,height=4.5)
v0=apply(B,1:2,sum)
v0[v0!=0]=1
v3=visualization(res$B_est,percent=1-mean(v0),window=0.4)
v3[v3!=0]=1
image(v3,axes=F,frame.plot=TRUE,las=1)
axis(1, at=(1:6)/6.8, labels=(1:6)*10, tck=-0.02,col = NA,col.ticks = 1,cex.axis=0.7,padj=-1.5)
axis(2, at=(1:6)/6.8, labels=(1:6)*10, tck=-0.02,col = NA,col.ticks =1,las=1,cex.axis=0.7)
dev.off()

pdf("circle.pdf",width=4,height=4.5)
image(v0,axes=F,frame.plot=TRUE,las=1)
axis(1, at=(1:6)/6.8, labels=(1:6)*10, tck=-0.02,col = NA,col.ticks = 1,cex.axis=0.7,padj=-1.5)
axis(2, at=(1:6)/6.8, labels=(1:6)*10, tck=-0.02,col = NA,col.ticks =1,las=1,cex.axis=0.7)
dev.off()


prediction_lasso
prediction_logistic
prediction_ours
prediction_CNN

classification_lasso
classification_logistic
classification_ours
classification_CNN

selection_lasso
selection_logistic
selection_ours

save(prediction_lasso,prediction_logistic,prediction_ours,prediction_CNN,classification_lasso,classification_logistic,classification_ours,classification_CNN,selection_lasso,selection_logistic,selection_ours,file="Figure14.RData")

#######################################################
########### classification plot #################################
#######################################################
load("Figure14.RData")
nsim=30;
library(ggplot2)
error=c(mean(classification_lasso),mean(classification_CNN),mean(classification_logistic),mean(classification_ours))
sd=c(sd(classification_lasso),sd(classification_CNN),sd(classification_logistic),sd(classification_ours))/sqrt(nsim)
method=factor(c("Lasso","CNN","LogisticGraph","NonparaGraph"),levels = c("Lasso","CNN","LogisticGraph","NonparaGraph"))

data_c=data=data.frame(error=error,sd=sd,method=as.factor(method))

p=ggplot(data,aes(x=method,y=error,fill=method))+
geom_bar(stat="identity", position=position_dodge()) +
geom_errorbar(aes(ymin=error-sd, ymax=error+sd), width=.2,
position=position_dodge(.9))+scale_fill_manual(values=c("#D6CFC4","#CCC591","#BCA455","#069AA0"))

pdf("classification.pdf",width=6,height=4)
p
dev.off()
########### regression plot #################################
#######################################################
error=c(mean(prediction_lasso),mean(prediction_CNN),mean(prediction_logistic),mean(prediction_ours))
sd=c(sd(prediction_lasso),sd(prediction_CNN),sd(prediction_logistic),sd(prediction_ours))/sqrt(nsim)
method=factor(c("Lasso","CNN","LogisticGraph","NonparaGraph"),levels = c("Lasso","CNN","LogisticGraph","NonparaGraph"))

data_r=data=data.frame(error=error,sd=sd,method=as.factor(method))

p=ggplot(data,aes(x=method,y=error,fill=method))+
geom_bar(stat="identity", position=position_dodge()) +
geom_errorbar(aes(ymin=error-sd, ymax=error+sd), width=.2,
position=position_dodge(.9))+scale_fill_manual(values=c("#D6CFC4","#CCC591","#BCA455","#069AA0"))+coord_cartesian(ylim = c(0,.32))
pdf("regression.pdf",width=6,height=4)
p
dev.off()

####
data=rbind(data_c,data_r)
data=cbind(data,c(rep("classification",4),rep("regression",4)))
names(data)[4]="metric"
data[,4]=factor(data[,4],levels=c("regression","classification"))
data[,3]=factor(data[,3],levels=c("Lasso","CNN","LogisticGraph","NonparaGraph"))
p=ggplot(data,aes(x=method,y=error,fill=metric))+geom_bar(stat="identity", position=position_dodge())
p=p+scale_fill_manual(values=c("#1F78B4","#A6CEE0"))+geom_errorbar(aes(ymin=error-sd, ymax=error+sd), width=.2,position=position_dodge(.9))+coord_cartesian(ylim = c(0,.32))
pdf("total_error.pdf",width=6,height=4)
p
dev.off()
#####






auc=c(mean(selection_lasso),mean(selection_logistic),mean(selection_ours))
sd=c(sd(selection_lasso),sd(selection_logistic),sd(selection_ours))/sqrt(20)
method=factor(c("Lasso","LogisticGraph","NonparaGraph"),levels = c("Lasso","LogisticGraph","NonparaGraph"))

data=data.frame(est=auc,sd=sd,method=as.factor(method))
p=ggplot(data,aes(x=method,y=auc,fill=method))
p=p+geom_bar(stat="identity", position=position_dodge())+coord_cartesian(ylim = c(0,1))+scale_fill_manual(values=c("#D6CFC4","#CCC591","#069AA0"))+geom_errorbar(aes(ymin=est-sd, ymax=est+sd), width=.2,
position=position_dodge(.9))

pdf("selection.pdf",width=6,height=4)
p
dev.off()


#################### model fitting ####################
############### method 3. Our method  ##############################
tem=array(0,dim=c(d,d,5))
for(i in 1:5){
    m=res3$B_est[,,1+2*(i-1)]+res3$B_est[,,2+2*(i-1)]
    m=m/norm(m,"F")
    #tem[,,i][sort(abs(m),index=T,decreasing=T)$ix[1:100]]=1
    tem[,,i]=m
}
library("RColorBrewer")
marker = list(color = brewer.pal(11, "RdBu"))$color
levelplot(tem,at= c(seq(-max(abs(tem)), max(abs(tem)), length=12)),col.regions=marker)

pdf("est.pdf",width=15,height=5)
dev.off()

############### comparison ##############################
sum(dbinom(0.5*(y+1),1,prob,log=TRUE))
sum(dbinom(0.5*(y+1),1,prob_est(pred),log=TRUE))
sum(dbinom(0.5*(y+1),1,res$Yfit,log=TRUE))
library(pROC)
plot.roc(y, pb)
plot.roc(y, prob,add=T,col="blue") ## lasso
plot.roc(y,prob_est(pred),add=T,col="red")## ours
plot.roc(y, res$Yfit,add=T,col="yellow")## graphical

sum(abs(prob_est(pred)-pb))
sum(abs(res$Yfit-pb))
sum(abs(prob-pb))


### method 4. BNSP; slow.....
burnin <- 15
postburn <- 10
niter <- 25
outlist <- BNSPfunc(Xmat = xnew,y = 10*y, V = 68, R = 5, niter = niter)
q <- outlist$q
betamat <- outlist$betamat
betasample <- matrix(NA,postburn,q)
for(i in 1:postburn){
    betasample[i,] <- upperTriangle(betamat[i+burnin,,],byrow=T)
}
get_matrix(colMeans(betasample))
rn.gen <- outlist$rn.gen
colMeans(rn.gen[(burnin+1):niter,]) #### Detected Nodes if greater than 0.5
length(which(colMeans(rn.gen[(burnin+1):niter,])>0.5))

response=NULL
for(i in 1:n){
response=c(response,sum(X[[i]]*get_matrix(colMeans(betasample))))
}
response=(response-mean(response))/sd(response)
response=1/(1+exp(-response))

############### cross validation ####################
support=max(sum(apply(apply(B,1:2,sum),1,sum)!=0),sum(apply(apply(B,1:2,sum),2,sum)!=0))
library(rTensor)
truer=max(sum(svd(unfold(as.tensor(B),c(1,3),2)@data)$d>1e-3),sum(svd(unfold(as.tensor(B),c(2,3),1)@data)$d>1e-3))
############### ###############
truer=c(15)
sparse=c(20,30,40)
config=cbind(c(5,5,5,10,10,10),c(sparse,sparse))

fold_index= (1:160 %% 5) + 1
error=matrix(0,nrow=6,ncol=7)
for(i in 1:6){
    truer=config[i,1];support=config[i,2]
    error[i,1]=truer;error[i,2]=support
for(fold in 1:5) {
    hold=sample(1:160)[fold_index==fold]
    res3=NonparaMatrix(X_train[-hold],y_train[-hold],X_train[hold],truer=truer,support=support)
    error[i,2+fold]=mean(abs(res3$prob-pb_train[hold]))
}
}

#################### cross validation for lasso ###############
cv.out <- cv.glmnet(xvec,y,alpha = 1, family = "binomial",type.measure = "mse")
cv.out$lambda.min
