### Figure 6. continous. error vs matrix dimension; fixed sample size; beta=0
source("NonMar.R")
library(ggplot2)
set.seed(1)
truer = 2; support = 2;
truer = 2; support = 5;
truer = 5; support = 5; ## overfit; cannot use 8,8
hyper_list=rbind(c(2,2),c(2,5),c(5,5))

signal=1
nsim=30
d_list=c(20,30,40,50,60)
#error=error_set=array(0,dim=c(3,length(d_list),nsim))
error=error_set=rep(0,nsim)


args <- (commandArgs(trailingOnly=TRUE))
cat(args[1])
if(length(args) == 1){
    BATCH <- as.numeric(args[1])
} else {
    stop()
}
indset = matrix(0,nrow = 15,ncol = 2)
s = 0
for(i in 1:3){
    for(j in 1:5){
        s = s+1
        indset[s,]= c(i,j)
    }
}
hyper = indset[BATCH,][1]
config = indset[BATCH,][2]

#for(hyper in 1:3){
    truer=hyper_list[hyper,1];support=hyper_list[hyper,2]
#      for(config in 1:length(d_list)){
        n = 200; d=d_list[config];
        sparse = d - support;
        ## simulate B
        rU = randortho(d)[,1:truer]
        rV= randortho(d)[,1:truer]
        B = rU%*%t(rV)
        B[1:sparse,]=0
        B[,1:sparse]=0


        for(sim in 1:nsim){
                    
            X = list();
            for(i in 1:n){
                X[[i]] = matrix(runif(d^2,-1,1),nrow =d,ncol = d)
            }
            ystar= unlist(lapply(X,function(x) sum(B*x)))
            
        
            ystar1=qnorm(1/(n+1)*(1:n))[rank(ystar)]
            ## seperable model
             pb= link(type="gap")(ystar1)
            
            ##### data
            y=rnorm(n,pb,0.1)
            
            
            ###################### prediction accuracy
            X_new = list();
            for(i in 1:500){
                X_new[[i]] = matrix(runif(d^2,-1,1),nrow =d,ncol = d)
            }
            ystar_new1=ystar_new=unlist(lapply(X_new,function(x) sum(B*x)))
            ystar_new1[ystar_new<0]=-1
            ystar_new1[ystar_new>=0]=1
            pb_new=link(type="gap")(ystar_new1)
            ###########
            
            res=NonparaMatrix(X,y,X_new=X_new,r=truer,sparse_r=sparse,sparse_c= sparse,H=sqrt(n)-8,lambda=0,rho.ini=1,min=max(-1,min(y)),max=min(1,max(y)))
            
            #error[sim]=mean(abs(res$prob-pb))
            error[sim]=mean(abs(res$prob-pb_new))
            #}
            #}
            print(paste("hyper",hyper,"-config",config,"-simulation",sim," is done",sep = ""))
}

save(error,file=paste("Figure6-reg-hyper",hyper,"-config",config,".RData",sep=""))

#data=cbind(c(t(error[3,,])),rep(1:5,rep(5,5)))
#data=data.frame(est=data[,1],d=as.factor(data[,2]))
#p=ggplot(data,aes(x=d,y=est))+geom_violin()

####################
### fixed n, increase d

###################



library(ggplot2)
Terror=Terror_set=array(0,dim=c(3,length(d_list),nsim))

for(hyper in 1:3){
    for(config in 1:length(d_list)){
        load(file=paste("Figure6-reg-hyper",hyper,"-config",config,".RData",sep=""))
        Terror[hyper,config,]=error
        Terror_set[hyper,config,]=error_set
    }
}
error=Terror

plotdata =data.frame(error=c(t(apply(error,1:2,mean))),sd=c(t(apply(error,1:2,sd))),d=rep(d_list,3),setting=rep(c("r=2,s=2","r=2,s=5","r=5,s=5"),rep(5,3)))


plotdata[,2]=plotdata[,2]/sqrt(30)


#fun.1 <- function(x) 0.2/x^(1/3)
fun.1 <- function(x) 0.095*log(x)

pdf("Figure6.pdf",width=6,height=5)
#figure = ggplot(data = plotdata, aes(x = d,y = error),shape=1)+theme(axis.text.y = element_text(size = 16),axis.text.x = element_text(size = 16), axis.title.x = element_text(size = 16), axis.title.y = element_text(size = 16))+geom_point(aes(shape=setting),size = 2)+geom_line(aes(color=setting))+labs(y = "excess classification risk",x = "matrix dimension",size = 16)+geom_ribbon(aes(ymin=error-1.96*sd,ymax=error+1.96*sd,fill=setting),alpha=0.3)+coord_cartesian(ylim = c(0,0.07))

figure = ggplot(data = plotdata, aes(x = d,y = error),shape=1,color=1)+theme(axis.text.y = element_text(size = 16),axis.text.x = element_text(size = 16),axis.title.x = element_text(size = 16),axis.title.y = element_text(size = 16),)+geom_line(aes(color=setting),size=1.5)+labs(y = "regression error",x = "matrix dimension")+geom_point(aes(shape=setting),size = 2)+scale_color_manual(values=c("#C4961A", "#4E84C4", "#52854C"))

figure=figure+ geom_errorbar(aes(ymin=error-sd,ymax=error+sd),width=0.001,position=position_dodge(0.01))+coord_cartesian(ylim = c(0.1,0.4))+scale_shape_manual(values = c(1,4,2))+stat_function(fun = fun.1,linetype = 2)


