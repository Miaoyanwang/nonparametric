pdf("high_rank.pdf",width=5.4,height=5)
library(fields)
d=10
Z=matrix(0,nrow=d,ncol=d)
for(i in 1:d){
    for(j in 1:d){
        Z[i,j]=log(1+max(i,j))
        }
  }
image.plot(Z,axes=F,frame.plot=TRUE,las=1)
axis(1, at=seq(from=0,to=1,length=10), labels=(1:10))
axis(2, at=seq(from=0,to=1,length=10), labels=(1:10),las=1)
dev.off()



library(ggplot2)
set.seed(1)
d=50;r=5;
data_full=NULL
for(nsim in 1:10){
a=matrix(rnorm(d*r),ncol=r)
T=a%*%t(a)
c=c(0.1,0.2,0.4,0.8,2,4,6,8,10,15,20,25,30,40,50,60,70,80,90,100)
rank2=accuracy=NULL
for(i in 1:20){
T_trans=1/(1+exp(-(c[i]*T)))
rank2=c(rank2,which(sqrt(cumsum(svd(T_trans)$d^2))>0.99*sqrt(sum(T_trans^2)))[1])
}
data=data.frame(c,rank2)
colnames(data)=c("c","rank")
data_full=rbind(data_full,data)
}

data_full=cbind(data_full,rep(1:10,rep(20,10)))
colnames(data_full)=c("c","rank","sim")
save(data_full,file="example1.RData")

ag <- aggregate(. ~ c, data_full, function(x) c(mean = mean(x), sd = sd(x)))

plotc=1:20
ag=ag[plotc,]
pdf("example1.pdf",width=3.2,height=3)
ggplot(ag,aes(c,rank[,1]))+geom_point(aes(c,rank[,1]),size=0.5)+geom_line(aes(c,rank[,1]))+geom_errorbar(aes(ymin=rank[,1]-rank[,2]/sqrt(10), ymax=rank[,1]+rank[,2]/sqrt(10)), width=.2)+labs(x = "transformation level (c)")+labs(y = "numerical rank")
dev.off()
