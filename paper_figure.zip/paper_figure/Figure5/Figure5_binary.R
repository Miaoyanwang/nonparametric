### Figure 5. binary. error vs sample size; fixed matrix dimension; beta=0
source("NonMar.R")
set.seed(1)
truer = 2; support = 2;
truer = 2; support = 5;
truer = 5; support = 5; ## overfit; cannot use 8,8
hyper_list=rbind(c(2,2),c(2,5),c(5,5))

#signal=3;
nsim=30; #hyper=1;
n_list=c(150,200,250,300,350)
error=rep(0,nsim)

args <- (commandArgs(trailingOnly=TRUE))
cat(args[1])
if(length(args) == 1){
    BATCH <- as.numeric(args[1])
} else {
    stop()
}
indset = matrix(0,nrow = 15,ncol = 2)
s = 0
for(i in 1:3){
    for(j in 1:5){
    s = s+1
    indset[s,]= c(i,j)
}
}
hyper = indset[BATCH,][1]
config = indset[BATCH,][2]

#for(hyper in 1:3){
    truer=hyper_list[hyper,1];support=hyper_list[hyper,2]
#   for(config in 1:length(n_list)){
        n = n_list[config]; d=20;
        sparse = d - support;
        ## simulate B
        rU = randortho(d)[,1:truer]
        rV= randortho(d)[,1:truer]
        B = rU%*%t(rV)
        B[1:sparse,]=0
        B[,1:sparse]=0

        for(sim in 1:nsim){
            X = list();
            for(i in 1:n){
                X[[i]] = matrix(runif(d^2,-1,1),nrow =d,ncol = d)
            }
            ystar= unlist(lapply(X,function(x) sum(B*x)))
            ## logistic model

            ystar1=qnorm(1/(n+1)*(1:n))[rank(ystar)] ##half positive; half negative
            ## seperable model
            pb= link(type="gap")(ystar1)
            
             y = ifelse(sapply(pb,function(x) rbinom(1,1,(x+1)/2))==1,1,-1)
            
            ########### predicton accuracy
            X_new = list();
            for(i in 1:500){
                X_new[[i]] = matrix(runif(d^2,-1,1),nrow =d,ncol = d)
            }
            ystar_new1=ystar_new=unlist(lapply(X_new,function(x) sum(B*x)))
            ystar_new1[ystar_new<0]=-1
            ystar_new1[ystar_new>=0]=1
            pb_new=link(type="gap")(ystar_new1)
            #######
        res=NonparaMatrix(X,y,X_new=X_new,r=truer,sparse_r=sparse,sparse_c= sparse,H=sqrt(n)-8,lambda=0,rho.ini=1,min=max(-1,min(y)),max=min(1,max(y)))
        
        ###
        ##error[sim]=mean(abs(res$prob-pb))
           error[sim]=mean(abs(res$prob-pb_new))
            
            print(paste("hyper",hyper,"-config",config,"-simulation",sim," is done",sep = ""))
        }
# }
#}

#save(final,file=paste("cv",r,"-",cost,"-",k,".RData",sep=""))


save(error,file=paste("Figure5-binary-hyper",hyper,"-config",config,".RData",sep=""))
#data=cbind(c(t(error)),rep(1:5,rep(5,5)))
#data=data.frame(est=data[,1],d=as.factor(data[,2]))
#p=ggplot(data,aes(x=d,y=est))+geom_violin()

####################
### fixed n, increase d

###################



library(ggplot2)

Terror=Terror_set=array(0,dim=c(3,length(n_list),nsim))

for(hyper in 1:3){
    for(config in 1:5){
        load(file=paste("Figure5-binary-hyper",hyper,"-config",config,".RData",sep=""))
        Terror[hyper,config,]=error
    }
}
error=Terror


plotdata =data.frame(error=c(t(apply(error,1:2,mean))),sd=c(t(apply(error,1:2,sd))),n=rep(n_list,3),setting=rep(c("r=2,s=2","r=2,s=5","r=5,s=5"),rep(5,3)))

plotdata[,2]=plotdata[,2]/sqrt(30)

fun.1 <- function(x) 8/x^(1/2)



pdf("Figure5.pdf",width=6,height=5)
figure = ggplot(data = plotdata, aes(x = n,y = error),shape=1,color=1)+theme(axis.text.y = element_text(size = 16),axis.text.x = element_text(size = 16),axis.title.x = element_text(size = 16),axis.title.y = element_text(size = 16),)+geom_line(aes(color=setting),size=1.5)+labs(y = "regression error",x = "sample size")+geom_point(aes(shape=setting),size = 2)+scale_color_manual(values=c("#C4961A", "#4E84C4", "#52854C"))

figure=figure+ geom_errorbar(aes(ymin=error-sd,ymax=error+sd),width=0.001,position=position_dodge(0.01))+coord_cartesian(ylim = c(0.2,0.65))+scale_shape_manual(values = c(1,4,2))+stat_function(fun = fun.1,linetype = 2)
